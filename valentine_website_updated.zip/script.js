const noBtn = document.getElementById("noBtn");
const yesBtn = document.getElementById("yesBtn");

noBtn.addEventListener("mouseover", function() {
    const x = Math.random() * (window.innerWidth - 100);
    const y = Math.random() * (window.innerHeight - 50);
    noBtn.style.left = `${x}px`;
    noBtn.style.top = `${y}px`;
});

yesBtn.addEventListener("click", function() {
    document.body.innerHTML = `
        <div class="container">
            <h1>YAY! 🎉 I knew you'd say yes! 💖</h1>
            <img src="https://media.giphy.com/media/l3q2K5jinAlChoCLS/giphy.gif" alt="Happy GIF" />
        </div>
    `;
});

// Floating hearts animation
setInterval(() => {
    let heart = document.createElement("div");
    heart.className = "heart";
    heart.innerHTML = "❤️";
    heart.style.left = Math.random() * window.innerWidth + "px";
    document.body.appendChild(heart);
    setTimeout(() => heart.remove(), 4000);
}, 500);
